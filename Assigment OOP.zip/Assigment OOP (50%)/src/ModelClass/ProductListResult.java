package ModelClass;

public class ProductListResult {

}
