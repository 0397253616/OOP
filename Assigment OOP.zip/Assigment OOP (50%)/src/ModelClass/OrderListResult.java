package ModelClass;

public class OrderListResult {

}
